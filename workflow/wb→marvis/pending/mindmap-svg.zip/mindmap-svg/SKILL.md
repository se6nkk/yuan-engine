---
name: mindmap-svg
description: Generate clean diagrams as inline SVG via the Visualizer diagram module — (1) left-to-right / radial mind maps / 脑图 / 思维导图 from a node hierarchy, (2) minimal vertical timelines / 发展脉络 / 时间轴 with time on the left and events on the right, and (3) misconception-contrast layouts / 误区对照 (misconception on top; correct answer + insight side-by-side below). Use when the user wants a polished concept map, domain taxonomy, knowledge graph, clean chronology, or a "myth vs truth" comparison and finds generic box-and-line / card-stacked diagrams ugly. Encodes the exact layout math, flat-design constraints, color system, connector styling, and typography that yield a clean organic result.
agent_created: true
---

# Mindmap SVG

## Overview
Produce beautiful mind maps as inline SVG rendered through the Visualizer `show_widget`
tool with the `diagram` module. The output reads as an organic, radiating concept map —
NOT a stiff box-and-line tree. This skill encodes the exact layout math, color system,
connector styling, and typography that consistently yield a clean result.

## When to use
- User asks for a 脑图 / 思维导图 / mind map / concept map / domain taxonomy.
- User asks for a 发展脉络 / 时间轴 / 时间线 / timeline / chronology (a sequence of dated
  milestones, events, or phases).
- User wants a 误区对照 / 误区vs正解 / myth-vs-truth / misconception contrast — especially the
  confirmed style where the misconception sits on TOP and the correct answer + insight sit
  side-by-side BELOW (so readers remember the correction, not the error).
- User shares an ugly existing diagram and wants it redrawn beautifully.
- Output must be an inline visual (not a standalone image file) — use `show_widget`. To also
  hand over a file, export the same SVG to disk (see Assets).

## Hard design-system constraints (Visualizer diagram module)
These are mandatory; violating them produces the "tool-like" look the user dislikes.
- Flat only: no gradients, shadows, blur, glow, or neon.
- Outer container transparent (host provides background). A page background fill of `#FBFAF7`
  inside the SVG is acceptable.
- `viewBox` width fixed at `680` (`"0 0 680 H"`), `width="100%"`.
- Typography: two weights only — `400` regular and `500` medium. Sizes: root 14px, hub 13px,
  leaf 12px, title 15px. No font below 11px.
- No emoji, no rotated text, no `<!--` comments.
- Connectors (paths/polylines) MUST have `fill="none"`.
- Color palette: 9 ramps (c-purple, c-blue, c-pink, c-teal, c-amber, c-coral, c-green,
  c-red, c-gray) × 7 levels (50→900). Light-mode rule: node = `50` fill + `600` stroke +
  `800/900` text. Use the ramp hex values directly (see references/palette.md).
- Font family: `-apple-system, system-ui, sans-serif`.
- **CRITICAL — `widget_code` must contain EXACTLY ONE root `<svg>` element.**
  - Pure-HTML mode: NO embedded `<svg>` allowed (the validator rejects it).
  - SVG mode: NO NESTED `<svg>` allowed (cannot draw icon glyphs with inner `<svg>`).
  - **To get natural text wrapping** (Chinese auto line-break, no manual `<tspan>`): use a single
    root `<svg>` + one or more `<foreignObject>` elements whose child is standard HTML
    (`<div xmlns="http://www.w3.org/1999/xhtml" style="...">`). CSS wraps automatically.
  - Inside `<foreignObject>` HTML, draw markers as COLORED TEXT GLYPHS, not svg icons:
    `✗` (red `#993556`), `✓` (green `#0F6E56`), `•` (gray `#888780`). Never nest an `<svg>` marker.
  - Block-level separators (lines) must be drawn as SVG `<line>` OUTSIDE the foreignObject,
    positioned by coordinates.

## Recipe — left-to-right radiating mind map (default)
Layout (3 levels):
1. Root: a capsule on the LEFT. `rx=25`, filled `#3C3489`, white text, centered,
   `dominant-baseline="central"`.
2. Category hubs: pills at `x≈240`, `rx=17`, filled with the category's `600` color, white text.
3. Leaf nodes: pills at `x≈480`, `rx=15`, filled with category `50` color + `600` stroke
   (`0.6` width) + `800/900` text.

Connectors:
- Root → hub: cubic bezier `C`, stroke = category `600` color, `opacity 0.55`, `width 2`,
  `stroke-linecap="round"`.
- Hub → leaf: cubic bezier `C`, stroke = category `600` color, `opacity 0.5`, `width 1.5`.
- All connector paths: `fill="none"`.

Vertical placement:
- Stagger category hubs down the left-center; give the densest category (most leaves) the
  tallest vertical band.
- Place each category's leaves clustered to the right of its hub, centered on the hub's y.

Title: top-center text "N. 标题" at 15px/500 `#444441`.

## Color assignment by category
Assign each top-level category one ramp so branches stay color-coded:
- 主要领域 → blue (`#185FA5` hub / `#E6F1FB` leaf fill / `#0C447C` leaf text)
- 子领域 → pink (`#993556` / `#FBEAF0` / `#72243E`)
- 交叉领域 → teal (`#0F6E56` / `#E1F5EE` / `#085041`)
- 医学诊断 → amber (`#854F0B` / `#FAEEDA` / `#633806`)
Reuse `references/palette.md` to pick other ramps for additional categories.

## Workflow
1. Parse the hierarchy: root → categories → leaves. Count leaves per category to size bands.
2. Compute coordinates (keep within safe area x:40–640, y:40–H-40). Set
   `H = bottommost element + 20`.
3. Emit `<svg viewBox="0 0 680 H">` with: title text, connector paths, then nodes
   (root, hubs, leaves) each as `<g>`/`<rect>`+`<text>`.
4. Render via `show_widget` (modules: `["diagram"]`) — call `read_me` first. Provide
   `loading_messages`.
5. Optional: write the same SVG to disk as a `.svg` file so other agents/users can reuse it
   as a template.

## Alternative — centered radial mind map
When the user prefers a true radial map: place the root `circle` r=44 at center
`(340, H/2)`, four category hubs on compass points, leaves further out along curved bezier
branches. Same color/weight/curve rules apply.

## Recipe — minimal vertical timeline (default for 发展脉络 / 时间轴)
The user's confirmed preferred style for chronologies. Minimal, no boxes, no fills.

Layout:
- A thin gray vertical axis at `x=190`: `<line x1="190" y1="40" x2="190" y2=H-22 ... stroke="#B4B2A9" stroke-width="1.2" stroke-linecap="round">`.
- Time labels: RIGHT-aligned at `x=175`, `text-anchor="end"`, 15px/500 `#444441`.
- Event text: LEFT-aligned at `x=205`, 15px/400 `#444441`.
- Node dots: `<circle cx="190" r="4" fill="#5F5E5A">`, `cy = row_first_line_y - 5` so the dot
  sits vertically CENTERED with the first line of text (not on the baseline).
- NO title, NO rectangles (no `<rect>` cards), NO background fills except the page `#FBFAF7`.
- ALL text unified color `#444441`, unified size 15px (only weight differs: 500 time / 400 event).

Row math:
- First line baseline `y` for row i. Single-line rows use one `<text>`; long events wrap to a
  second line at `y+24`.
- Space rows ~64px apart (start y≈50). `H = last_row_bottom + 20`.
- Top-alignment rule: each row's time label and event first line share the SAME `y` (top aligned).

Wrapping: SVG `<text>` does not auto-wrap — break long events into 2 `<text>` lines by semantic
pause (comma / clause boundary). Keep each line ≤ ~31 Chinese chars so it stays within x:205–640.

Quick template: copy `assets/timeline-template.svg` and replace the placeholder texts.

## Recipe — misconception contrast (误区对照 / 误区置顶 · 正解洞察并排)
The user's confirmed preferred style for "myth vs truth" comparisons. The key insight:
putting the misconception side-by-side with the correct answer makes readers remember the
ERROR. Instead, place the misconception ALONE on TOP, then put the correct answer and the
deeper insight side-by-side BELOW — so the (correction + insight) pair becomes the memory anchor.

Layout (per group, ~180px tall; 4 groups at y = 10 / 190 / 370 / 550):
1. Misconception (top, full width): `<foreignObject x="44" y=组y width="592" height="52">`
   HTML = `✗` (red) + `误区` bold + text. `#444441`, 14px.
2. Horizontal separator line: `<line x1="44" y1=组y+58 x2="636" y2=组y+58 stroke="#ededea" stroke-width="1"/>`.
3. Correct answer (below-left, WIDE): `<foreignObject x="44" y=组y+64 width="368" height="104">`
   HTML = `✓` (green `#0F6E56`) + `正解` bold + text. `#444441`, 14px.
4. Insight (below-right, NARROW): `<foreignObject x="430" y=组y+64 width="206" height="104">`
   HTML = `•` (gray `#888780`) + `洞察` bold + text. `#888780`, 13px.
5. Vertical separator between the two lower columns: `<line x1="420" y1=组y+66 x2="420" y2=组y+158 stroke="#e3e1da" stroke-width="1"/>`.

Style rules:
- No title, no `<rect>` cards, no background fills (transparent). Only 1px light-gray lines.
- Markers are COLORED TEXT GLYPHS (`✗/✓/•`), NOT svg icons (see the CRITICAL constraint above).
- Text inside `<foreignObject>` wraps automatically — do NOT manually break lines.
- Unified text color `#444441` (insight `#888780`); sizes 14/13; weights 400/500 only.

To widen/narrow columns: keep `44 + 正解宽 ≈ 412`, vertical line at `420`, insight `x=430`,
and `正解宽 + 206 + (430-44) ≤ 636`. Adjust `height` of the two lower foreignObjects if a
correct-answer text is long (3+ lines) — bump to 124 and extend the vertical line `y2` equally.

Quick template: copy `assets/contrast-template.svg` and replace the placeholder texts.

## Assets
- `assets/mindmap-template.svg` — ready-to-edit left-to-right mind map template (贝叶斯定理 example).
  Copy it and replace node texts/coordinates.
- `assets/timeline-template.svg` — ready-to-edit minimal vertical timeline template with
  placeholder 时间/事件 rows. Copy and replace texts.
- `assets/contrast-template.svg` — ready-to-edit misconception-contrast template (误区置顶 /
  正解宽栏 + 洞察窄栏). Copy and replace the `✗误区 / ✓正解 / •洞察` texts.

## References
- `references/palette.md` — full 9-ramp × 7-level hex palette for assigning category colors.
