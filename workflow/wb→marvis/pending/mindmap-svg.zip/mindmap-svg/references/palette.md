# Visualizer Color Palette (9 ramps × 7 levels)

Use these exact hex values. Light-mode node rule: `50` fill + `600` stroke + `800/900` text.
Hub pills use the `600` fill with white text. Connectors use the `600` color at 0.5–0.55 opacity.

| Ramp | 50 | 100 | 200 | 400 | 600 | 800 | 900 |
|------|-----|-----|-----|-----|-----|-----|-----|
| c-purple | #EEEDFE | #CECBF6 | #AFA9EC | #7F77DD | #534AB7 | #3C3489 | #26215C |
| c-blue   | #E6F1FB | #B5D4F4 | #85B7EB | #378ADD | #185FA5 | #0C447C | #042C53 |
| c-teal   | #E1F5EE | #9FE1CB | #5DCAA5 | #1D9E75 | #0F6E56 | #085041 | #04342C |
| c-pink   | #FBEAF0 | #F4C0D1 | #ED93B1 | #D4537E | #993556 | #72243E | #4B1528 |
| c-coral  | #FAECE7 | #F5C4B3 | #F0997B | #D85A30 | #993C1D | #712B13 | #4A1B0C |
| c-green  | #EAF3DE | #C0DD97 | #97C459 | #639922 | #3B6D11 | #27500A | #173404 |
| c-amber  | #FAEEDA | #FAC775 | #EF9F27 | #BA7517 | #854F0B | #633806 | #412402 |
| c-red    | #FCEBEB | #F7C1C1 | #F09595 | #E24B4A | #A32D2D | #791F1F | #501313 |
| c-gray   | #F1EFE8 | #D3D1C7 | #B4B2A9 | #888780 | #5F5E5A | #444441 | #2C2C2A |

## Suggested category → ramp mapping
- 主要领域 → c-blue
- 子领域 → c-pink
- 交叉领域 → c-teal
- 医学诊断 → c-amber
- 额外分类 → c-purple / c-green / c-coral / c-red (as needed)

## Neutral / text colors
- Page background: `#FBFAF7`
- Title text: `#444441` (c-gray 800)
- Root node fill: `#3C3489` (c-purple 800) with white text
